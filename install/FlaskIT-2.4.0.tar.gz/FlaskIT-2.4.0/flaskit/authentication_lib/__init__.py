
class Authent:
    def __init__(self):
        pass

    def authenticate(self):
        raise NotImplementedError("must be implemented")

    def authorize(self, obj, abort, check_acls):
        raise NotImplementedError("must be implemented")
