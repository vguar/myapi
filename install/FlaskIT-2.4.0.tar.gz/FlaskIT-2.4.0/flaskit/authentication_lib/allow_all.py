from flaskit.authentication_lib import Authent


class FreeAuthent (Authent):
    def authenticate(self):
        return

    def authorize(self, obj, abort, check_acls=False):
        options = {}
        return options
