# Flask imports
from flask import request, g
import flask_restful as restful

# Flaskit imports
from flaskit.cache import *


# Python imports
import logging
import os
from datetime import datetime


class Audit:
    # no audit by default
    audit_request = False
    audit_response = False
    audit_request_done = False

    def __init__(self):
        self.evaluate()

    # write audit request if defined
    def write_request(self):

        # already done
        if g.Audit.audit_request_done:
            return

        if self.audit_request:
            self.audit_request_done = True  # indicator this has be done (audit request is evaluated twice)
        else:
            # no audit
            return

        # write headers and body in separate files
        d = datetime.now()
        if app.config["AUDIT_LOG_DIR"][0] == "/":
            g.audit_dir = app.config["AUDIT_LOG_DIR"]
        else:
            g.audit_dir = "%s/%s" % (app.config["LOCAL_DIR"], app.config["AUDIT_LOG_DIR"])
        g.audit_dir = "%s/%s/%s/%s" % (g.audit_dir, d.strftime("%Y%m%d"), d.strftime("%H"), g.uuid)
        if not os.path.exists(g.audit_dir):
            os.makedirs(g.audit_dir)

        filename_headers = ""
        filename_body = ""
        try:
            filename_headers = "%s/request.headers.%s.audit" % (g.audit_dir, g.uuid)
            file = open(filename_headers, "w")
            file.write("%s %s HTTP/1.1\n" % (request.method, request.url.encode('ascii', 'replace')))
            for x in request.headers:
                file.write('%s: %s\n' % (x[0], x[1]))
            file.close()

            if len(request.data) != 0:
                filename_body = "%s/request.body.%s.audit" % (g.audit_dir, g.uuid)
                file = open(filename_body, "w")
                file.write(request.data)
                file.close()
        except Exception, e:
            # just log errors
            app.logger.exception(e)

        logger_audit = logging.getLogger("%s-audit" % app.config["API_NAME"])
        logger_audit.info(' '.join([
            "REQ_INFO",
            g.remote_addr,
            g.username,
            request.method,
            "%s" % request.endpoint,
            g.apiname,
            "\"%s\"" % request.url,
            "%d" % len(request.data),
            "\"%s\"" % ', '.join([': '.join(x) for x in g.main_headers])
        ]))
        logger_audit.info("REQ_HEAD %s" % filename_headers)
        if filename_body != "":
            logger_audit.info("REQ_BODY %s" % filename_body)

    # write audit response if defined
    def write_response(self, response):

        # no audit
        if self.audit_response == False:
            return

        filename_headers = ""
        filename_body = ""
        try:
            filename_headers = "%s/response.headers.%s.audit" % (g.audit_dir, g.uuid)
            file = open(filename_headers, "w")
            file.write("HTTP/1.0 %s\n" % response.status)
            for x in response.headers:
                file.write('%s: %s\n' % (x[0], x[1]))
            file.close()

            if len(response.data) != 0:
                filename_body = "%s/response.body.%s.audit" % (g.audit_dir, g.uuid)
                file = open(filename_body, "w")
                file.write(response.data)
                file.close()
        except Exception, e:
            # just log errors
            app.logger.exception(e)
            pass

        logger_audit = logging.getLogger("%s-audit" % app.config["API_NAME"])

        logger_audit.info(' '.join([
            "RSP_INFO",
            "%s" % response.status_code,
            "%s" % len(response.data),
            "%s" % g.delay_ms,
            "%s" % g.is_cached,
            "%s" % g.response_status,
            "\"%s\"" % str(g.response_message).split('\n', 1)[0],
        ]))
        logger_audit.info("RSP_HEAD %s" % filename_headers)
        if filename_body != "":
            logger_audit.info("RSP_BODY %s" % filename_body)

    # identify audit configuration for current request
    def evaluate(self):

        # Try to find the default definition in api
        if "audit" in g.API:
            audit_def = g.API["audit"]
            if (int(audit_def) & 0x01) != 0:
                self.audit_request = True
            if (int(audit_def) & 0x02) != 0:
                self.audit_response = True
