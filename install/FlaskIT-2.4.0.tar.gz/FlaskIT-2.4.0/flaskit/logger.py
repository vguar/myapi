# Flask imports
from flask import request, g

# Flaskit imports
from flaskit import app
from flaskit import main_constants as F

# Python imports
import os
import sys
import thread
import logging
from logging.handlers import TimedRotatingFileHandler


class AppLogFilter(logging.Filter):
    def filter(self, record):
        # uuid not alays defined (startup, outside request...)
        try:
            record.uuid = g.uuid
        except Exception:
            record.uuid = 'undef'

        # redefine 'levelname' to include specific loglevels (DEBUG2...)
        try:
            if record.levelno in loglevels_rev:
                record.levelname = loglevels_rev[record.levelno]
            else:
                record.levelname = "\"%s\"" % record.levelname
        except Exception:
            pass

        # redefine 'pathname' to limit length in logs
        try:
            # search for framework name
            pos = record.pathname.find("/%s/" % os.path.basename(F.FLASKIT_LOCAL_DIR))
            if pos != -1:
                pos += len(os.path.basename(F.FLASKIT_LOCAL_DIR)) + 2
                record.pathname = "#%s" % record.pathname[pos:]

            # search for application name
            pos = record.pathname.find("/%s/" % os.path.basename(app.config["LOCAL_DIR"]))
            if pos != -1:
                pos += len(os.path.basename(app.config["LOCAL_DIR"])) + 2
                record.pathname = record.pathname[pos:]
        except Exception:
            record.pathname = 'undef'
        return True


# write log request
def logger_write_request():
    # log request
    if len(request.data) == 0 or (int(g.logbody) & 0x01) == 0:
        datas = ""
    else:
        datas = '\n'.join([
            "",
            "##### >>>>> Begin body request %s #####" % g.uuid,
            "%s" % request.data,
            "##### >>>>> End body request %s #####" % g.uuid
        ])

    if (int(g.logrequest) & 0x01) == 1:
        app.logger.info(' '.join([
            "REQ",
            g.remote_addr,
            g.username,
            g.userfamily,
            request.method,
            "%s" % request.endpoint,
            g.apiname,
            "\"%s\"" % request.url,
            "%d" % len(request.data),
            "\"%s\"" % ', '.join([': '.join(x) for x in g.main_headers]),
            datas.decode("utf-8", "replace")
        ]))

    # track on which pid/ppid the request is running
    #try:
    #    app.logger.info(' '.join(["pid", "%s" % os.getpid(), "%s" % len(app.threaded.keys()), "%s" % sys.getsizeof(app.threaded), "%s" % thread.get_ident(), "%s" % g.thread_id]))
    #except Exception, e:
    #    app.logger.exception(e)


# write log response
def logger_write_response(response):
    # log response
    if len(response.data) == 0 or (int(g.logbody) & 0x02) == 0:
        datas = ""
    else:
        datas = '\n'.join([
            "",
            "##### <<<<< Begin body response %s #####" % g.uuid,
            "%s" % response.data,
            "##### <<<<< End body response %s #####" % g.uuid
        ])

    if (int(g.logrequest) & 0x02) != 0:
        app.logger.info(' '.join([
            "RSP",
            "%s" % response.status_code,
            "%d" % len(response.data),
            "%s" % g.delay_ms,
            "%s" % g.is_cached,
            "%s" % g.response_status,
            "\"%s\"" % g.response_message,
            datas.decode("utf-8", "replace")
        ]))


loglevels = {
    'CRITICAL': logging.CRITICAL,
    'ERROR': logging.ERROR,
    'WARNING': logging.WARNING,
    'INFO': logging.INFO,
    'DEBUG': logging.DEBUG,
    'DEBUG2': logging.DEBUG - 1
}
loglevels_rev = {}


def logger_set_loglevel(loglevel):
    if loglevel not in loglevels:
        app.logger.error("Invalid log level : %s" % loglevel)
        return

    # got main handler
    handler = app.logger.handlers[1]
    if handler.level != loglevels[loglevel]:
        #app.logger.debug("Set loglevel to %s" % loglevel)
        handler.setLevel(loglevels[loglevel])


def logger_configure():
    # Compute reverse resolution of loglevels
    for l in loglevels:
        loglevels_rev[loglevels[l]] = l

    # Main log configuration
    if app.config["LOG_LEVEL"] not in loglevels:
        raise Exception("Invalid log level %s" % app.config["LOG_LEVEL"])

    if app.config["MAIN_LOG_FILE"][0] == "/":
        log_filename = app.config["MAIN_LOG_FILE"]
    else:
        log_filename = "%s/%s" % (app.config["LOCAL_DIR"], app.config["MAIN_LOG_FILE"])
    log_dir = os.path.dirname(log_filename)
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    # handler = RotatingFileHandler(log_filename, maxBytes=1024*1024*1000, backupCount=app.config["LOGROTATE_NB_KEEP"])
    handler = TimedRotatingFileHandler(log_filename, when='D', interval=1, backupCount=app.config["LOGROTATE_NB_KEEP"])
    handler.setLevel(loglevels[app.config["LOG_LEVEL"]])
    formatter = logging.Formatter("[%(asctime)s] {%(pathname)s:%(lineno)d} %(uuid)s %(levelname)s - %(message)s")
    handler.setFormatter(formatter)
    app.logger.addFilter(AppLogFilter())
    app.logger.addHandler(handler)
    app.logger.setLevel(1)  # 1:lowest level possible (DEBUG is 10 !) -> filtering is done in handlers

    # Error log configuration
    if app.config["ERROR_LOG_FILE"][0] == "/":
        log_filename = app.config["ERROR_LOG_FILE"]
    else:
        log_filename = "%s/%s" % (app.config["LOCAL_DIR"], app.config["ERROR_LOG_FILE"])
    log_dir = os.path.dirname(log_filename)
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    # handler = RotatingFileHandler(log_filename, maxBytes=1024*1024*1000, backupCount=app.config["LOGROTATE_NB_KEEP"])
    handler = TimedRotatingFileHandler(log_filename, when='D', interval=1, backupCount=app.config["LOGROTATE_NB_KEEP"])
    handler.setLevel(logging.ERROR)
    formatter = logging.Formatter("[%(asctime)s] {%(pathname)s:%(lineno)d} %(uuid)s %(levelname)s - %(message)s")
    handler.setFormatter(formatter)
    app.logger.addHandler(handler)

    # Audit log configuration
    if app.config["AUDIT_LOG_FILE"][0] == "/":
        log_filename = app.config["AUDIT_LOG_FILE"]
    else:
        log_filename = "%s/%s" % (app.config["LOCAL_DIR"], app.config["AUDIT_LOG_FILE"])
    log_dir = os.path.dirname(log_filename)
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    logger_audit = logging.getLogger("%s-audit" % app.config["API_NAME"])
    # handler = RotatingFileHandler(log_filename, maxBytes=1024*1024*1000, backupCount=app.config["LOGROTATE_NB_KEEP"])
    handler = TimedRotatingFileHandler(log_filename, when='D', interval=1, backupCount=app.config["LOGROTATE_NB_KEEP"])
    formatter = logging.Formatter("[%(asctime)s] %(uuid)s - %(message)s")
    handler.setFormatter(formatter)
    logger_audit.addFilter(AppLogFilter())
    logger_audit.addHandler(handler)
    logger_audit.setLevel(logging.INFO)

    # Stats log configuration
    if app.config["STATS_LOG_FILE"][0] == "/":
        log_filename = app.config["STATS_LOG_FILE"]
    else:
        log_filename = "%s/%s" % (app.config["LOCAL_DIR"], app.config["STATS_LOG_FILE"])
    log_dir = os.path.dirname(log_filename)
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    logger_stats = logging.getLogger("%s-stats" % app.config["API_NAME"])
    # handler = RotatingFileHandler(log_filename, maxBytes=1024*1024*1000, backupCount=app.config["LOGROTATE_NB_KEEP"])
    handler = TimedRotatingFileHandler(log_filename, when='D', interval=1, backupCount=app.config["LOGROTATE_NB_KEEP"])
    formatter = logging.Formatter("%(asctime)s;%(uuid)s;%(message)s")
    handler.setFormatter(formatter)
    logger_stats.addFilter(AppLogFilter())
    logger_stats.addHandler(handler)
    logger_stats.setLevel(logging.INFO)
