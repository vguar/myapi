# Flaskit imports
from flaskit import app

def gSet(var, val, **kwargs):
    app.cache.set(var, val, **kwargs)


def gGet(var):
    return app.cache.get(var)
