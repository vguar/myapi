# Flask imports
from flask import request, g

# Flaskit imports
from flaskit import app

# Python imports
import logging

from pystatsd import Client


class Stats:
    def write(self, response):

        # Try to find the default definition in api
        if "stats" in g.API and g.API["stats"] == True:
            # log stats
            logger_stats = logging.getLogger("%s-stats" % app.config["API_NAME"])
            logger_stats.info(';'.join([
                "%s" % int(g.time_start),
                "%s" % app.config["API_VERSION"],
                g.remote_addr,
                g.userfamily,
                g.username,
                request.method,
                "%s" % request.endpoint,
                g.apiname,
                "\"%s\"" % request.url,
                "%s" % response.status_code,
                "%s" % len(request.data),
                "%s" % len(response.data),
                "%s" % g.delay_ms,
                "%s" % g.is_cached,
                "%s" % g.response_status,
                "\"%s\"" % str(g.response_message).split('\n', 1)[0],
            ]))

        if "statsd" in g.API and g.API["statsd"] == True:
            if "STATSD_HOST" in app.config and app.config["STATSD_HOST"] != "":
                sc = Client(app.config["STATSD_HOST"], app.config["STATSD_PORT"])
                if "STATSD_PREFIX" in app.config:
                    prefix = app.config["STATSD_PREFIX"]
                else:
                    prefix = "%s." % app.config["API_NAME"]

                sc.timing(prefix + 'endpoint.%s.method.%s.response_time' % (request.endpoint, request.method), g.delay_ms)
                sc.increment(prefix + 'endpoint.%s.method.%s.requests' % (request.endpoint, request.method))
                sc.increment(prefix + 'userfamily.%s' % g.userfamily)
                sc.increment(prefix + 'user.%s' % g.username)
                sc.increment(prefix + 'endpoint.%s.method.%s.userfamily.%s' % (request.endpoint, request.method, g.userfamily))
                sc.increment(prefix + 'endpoint.%s.method.%s.status_code.%s' % (request.endpoint, request.method, response.status_code))
                sc.gauge(prefix + 'endpoint.%s.method.%s.request_len' % (request.endpoint, request.method), len(request.data))
                sc.gauge(prefix + 'endpoint.%s.method.%s.response_len' % (request.endpoint, request.method), len(response.data))

                if not g.is_cached:
                    sc.timing(prefix + 'endpoint.%s.method.%s.response_time_nocache' % (request.endpoint, request.method), g.delay_ms)
                    sc.increment(prefix + 'endpoint.%s.method.%s.requests_nocache' % (request.endpoint, request.method))
