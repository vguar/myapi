# Flask lib
from flask import Flask
import flask_restful as restful
from flask_restful_swagger import swagger
from flask.ext.cache import Cache

# Flaskit imports
from flaskit import main_constants as F

# Standards lib
import os
import thread
import re
import time


class FlaskIT(Flask):

    def __init__(self):

        try:
            import mod_wsgi
            self.mod_wsgi = True
        except Exception, e:
            self.mod_wsgi = False


    def init(self, project_dir, env, api_name="api"):

        start_time = time.time()

        # Init flask framework (similar to app = Flask('app_name'))
        Flask.__init__(self, api_name)

        # Load config file
        config_path = "%s/env/%s" % (project_dir, env)
        config_file = "%s/config.cfg" % config_path
        app.config.from_pyfile(config_file)

        self.config["LOCAL_DIR"] = project_dir
        self.config["CONFIG_PATH"] = config_path
        self.config["CONFIG_FILE"] = config_file

        from flaskit.config import Config
        Config().check()

        # Execution from WSGI or built-in web server
        self.config["MOD_WSGI"] = self.mod_wsgi

        if self.config["MOD_WSGI"] == False:
            self.config['BASE_PATH'] = self.config['TEST_BASE_PATH']
            self.config['BASE_URL'] = self.config['TEST_BASE_URL']
            self.config['SPEC_URL'] = self.config['TEST_SPEC_URL']
            self.config['CURL_SAMPLE'] = self.config['TEST_CURL_SAMPLE']
            self.config['PREFIX_LOG_DIR'] = self.config['TEST_PREFIX_LOG_DIR']
            self.config['PREFIX_CACHE_DIR'] = self.config['TEST_PREFIX_CACHE_DIR']

        Config().templatize()

        # Init cache system
        if "CACHE_DIR" in self.config:
            if self.config["CACHE_DIR"][0] == "/":
                # need it for perms (builtin webserver/apache)
                self.config["CACHE_DIR"] = "%s/%s" % (self.config["CACHE_DIR"], os.getuid())
            else:
                # need it for perms (builtin webserver/apache)
                self.config["CACHE_DIR"] = "%s/%s/%s" % (self.config["LOCAL_DIR"], self.config["CACHE_DIR"], os.getuid())
        self.cache = Cache(self, config=self.config)
        if self.config["CACHE_RESET"] == True:
            self.cache.clear()

        # Set app secret key
        self.secret_key = "\xcf\xe3:\x86\xac\xa9'\xe8\x07\xe34k\x8c\xc8\xbc\x0c\x06\xc8+\xc2\x99\xe4\xb4\x9f"

        # Set HTTP Basic Realm
        self.config["HTTP_BASIC_AUTH_REALM"] = self.config['API_NAME']

        # No suggestion message for flask_restful.abort
        self.config["ERROR_404_HELP"] = False

        # redefine swaggerUI path (modified version)
        swagger.rootPath = "%s/%s/%s" % (F.FLASKIT_LOCAL_DIR, F.FLASKIT_NAME, "swaggerUI")
        self.api = swagger.docs(restful.Api(self),
                                apiVersion=self.config['API_VERSION'],
                                basePath=self.config['BASE_PATH'],
                                resourcePath=self.config['BASE_URL'],
                                produces=["application/json", "text/plain"],
                                api_spec_url=self.config['SPEC_URL'],
                                description=self.config['API_DESCRIPTION'])

        # Flaskit imports
        from flaskit.logger import logger_configure
        from flaskit.representation import output_json, output_text

        # configure logging
        logger_configure()

        self.logger.info("Starting app %s v%s (%s v%s)" % (self.config['API_NAME'],
                                                           self.config['API_VERSION'],
                                                           F.FLASKIT_NAME,
                                                           F.FLASKIT_VERSION))
        self.logger.info("PID %s TID %s" % (os.getpid(), thread.get_ident()))
        self.logger.info("API Console : %s%s.html" % (self.config['BASE_PATH'], self.config['SPEC_URL']))

        # Read and cache configuration
        Config().readAllConfigs()

        # Import routes
        from flaskit.routes import init_routes
        init_routes()

        self.logger.info("FlaskIT ready (%s sec)" % (time.time() - start_time))
        # Start internal web server
        if self.config["MOD_WSGI"] == False:
            app.run(host=self.config["TEST_HTTPSRV_HOST"], port=int(self.config["TEST_HTTPSRV_PORT"]), threaded=True)


app = FlaskIT()

