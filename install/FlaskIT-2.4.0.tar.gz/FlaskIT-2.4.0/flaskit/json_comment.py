import re
import json
from jsoncomment import JsonComment


# uncomment json string
# code extrated from commentjson 0.3 (https://github.com/vaidik/commentjson)
#  (class implementation is not suitable for this project as i need to use
# alternate class (jsoncomment) to also remove trailing comma)
def uncomment_json(text):
    regex = r'( |\t)*#.*$'
    regex_inline = r'(:?(?: |\t)*([A-Za-z\d\.{}]*)|(\".*\"),?)(?: |\t)*(#.*$)'
    lines = text.split('\n')
    excluded = []

    for index in xrange(len(lines)):
        if re.search(regex, lines[index]):
            if re.search(r'^' + regex, lines[index]):
                excluded.append(lines[index])
            elif re.search(regex_inline,
                           lines[index]):
                lines[index] = re.sub(regex_inline,
                                      r'\1', lines[index])

    for line in excluded:
        lines.remove(line)

    return '\n'.join(lines)


# Load non standard json from string
#  - comments are allowed
#  - trailing comma is allowed
# Processing is done in 2 steps
def load_json(str):
    # step 1 : uncomment string (using commentjson processing)
    str = uncomment_json(str)

    # step 2 : uncomment + remove trailing comma (using jsoncomment processing)
    data = JsonComment(json).loads(str)

    return data
