# Flaskit imports
from flaskit import app
from flaskit.logger import loglevels

# Flaskit imports
from flaskit.cache import gGet, gSet

import time

def init_routes():

    # store start time of the process (usefull for identify objects older) (can't to that in __init__, so it is a good place here)
    gSet("flaskit_startup_time", time.time())

    # Routes are dynamicaly build from routes definition (json files)
    routes = gGet("config.routes")
    for route in routes:
        # Dynamic load of module/class to identify route
        myclass = route["class"].split("@")
        if len(myclass) != 2:
            app.logger.error("Bad 'class' definition for endpoint '%s' : %s" % (str(route["endpoint"]), route["class"]))
            raise ImportError("Unable to load endpoint module '%s'" % route["endpoint"])
        try:
            module_name = myclass[0]
            class_name = myclass[1]
            module = __import__(module_name, fromlist=[class_name])
            klass = getattr(module, class_name)
        except ImportError, e:
            app.logger.exception(e)
            app.logger.error("Unable to import module %s:%s (%s)" % (module_name, class_name, e))
            raise Exception("Unable to load module '%s' for endpoint '%s'" % (module_name, route["endpoint"]))
        except AttributeError, e:
            app.logger.exception(e)
            app.logger.error("Unable to import class %s:%s (%s)" % (module_name, class_name, e))
            raise Exception("Unable to load class '%s' for endpoint '%s'" % (class_name, route["endpoint"]))
        except Exception, e:
            app.logger.exception(e)
            app.logger.error("Unable to import module/class '%s:%s' (%s:%s)" % (module_name, class_name, type(e), e))
            raise Exception("Unable to load module/class '%s:%s' for endpoint '%s'",
                            (module_name, class_name, route["endpoint"]))
    
        url = '%s%s' % (app.config["BASE_URL"], str(route["url"]))
        endpoint = "%s" % (str(route["endpoint"]))
        app.api.add_resource(klass, url, endpoint=endpoint)
        app.logger.log(loglevels["DEBUG2"],
                       "Load url route %s (endpoint:%s) to class %s (%s)" % (url, endpoint, class_name, module_name))

