===============
 FlaskIT async
===============

Cette version de flaskit permet de créer des APIS REST asynchrones (python2
uniquement).

Pour installer flaskit (venv fortement recommandé)::

  pip install ./bootstrap/Flask-Cache-0.13.adeo.1.tar.gz # version modifiée de Flask-Cache
  pip install -e . -r bootstrap-requirements.txt

Pour créer une nouvelle api::

  # Créé une API sans initialiser de dépôt git ni créer de venv
  $ ./bootstrap/flaskit_new_api.py --name myapi --dir ./myapi

Pour ajouter une resource à l'API::

  # (--all permet d'ajouter tous les types de requêtes existants)
  $ ./bootstrap/flaskit_add_resource.py --all --dir ./myapi --resource amazingresource
  [...]
  Lines to add to your token file (conf/auth.d/*.xml):
  ====================================================
      <api name="AmazingresourceGet" enabled="1" options="default=allow"/>
      <api name="AmazingresourceStatus" enabled="1" options="default=allow"/>
      <api name="AmazingresourceCount" enabled="1" options="default=allow"/>
      <api name="AmazingresourceFirstLast" enabled="1" options="default=allow"/>
      <api name="AmazingresourcePost" enabled="1" options="default=allow"/>
      <api name="AmazingresourceDelete" enabled="1" options="default=allow"/>

Il faut ensuite ajouter ces lignes dans myapi/auth.d/*.xml (exemple dans ``myapi/conf/auth.d/health.xml``).

Des Dockerfiles ainsi qu'un fichier ``docker-compose.yml`` sont générés. Pour
tester votre nouvelle api::

  $ cd myapi
  $ docker-compose down && docker-compose up -d --build

Il est également possible de scale les workers grace à l'option ``--scale``

ATTENTION: Ce n'est pas un déploiement de production. Ces images sont destinées
au développement uniquement.

L'API est servie sur le port 5000 de votre machine. Pour obtenir une spec, allez
sur http://localhost:5000/myapi/v1/spec.html.


Développement
=============

L'api en soi (``resources/*.py``) n'est pas censée être modifiée. Pour modifier les
tâches::

  $ $EDITOR consumer-RESOURCE/consumer/tasks.py

Le retour d'une tâche DOIT avoir le format suivant::

  {
    'success': (bool),
    'error_msg': (str) message d'erreur si success est True,
    'results': (list) résultats transmis par l'API,
  }

Une fois la modification effectuée::

  $ docker-compose down && docker-compose up -d --build

Pour effectuer une requête, utiliser les tokens présents dans ``conf/auth.d/*.xml``::

  $ grep token testapi/conf/auth.d/health.xml
  <auth token="8fa2e734-a762-4774-8a35-c6bd0b38702d" name="health" family="default" enabled="1" expire="" options="">

  $ export TOKEN=8fa2e734-a762-4774-8a35-c6bd0b38702d
  # un seul tiret à X-AuthToken
  $ curl http://127.0.0.1:5000/testapi/v1/_health -H "X-AuthToken: $TOKEN"

Des exemples de requêtes sont disponibles sur ``/myapi/v1/spec.html``.

États d'une tâche
=================

Une tâche peut avoir 4 états (que l'on peut obtenir sur
``/myapi/v1/resource/task_id/status``):

* ``PENDING``: La tâche n'existe pas ou n'est pas encore en cours de traitement

* ``STARTED``: La tâche est en cours de traitement

* ``SUCCESS``: La tâche est terminée, son résultat est disponible

* ``FAILURE``: Une exception imprévue a eu lieu durant l'exécution de la tâche

Tester une tâche sans API
=========================

.. code-block:: shell

   cd myapi/consumer-xxx
   pip install -e .
   run-tasks -d '{"description": "awesome-description"}'

oc policy add-role-to-user edit -z default

Tests unitaires et fonctionnels
===============================

Les tests unitaires et fonctionnels sont lancés via ``pytest``. Il se trouvent
dans consumer-xxx/consumer/tests.

Pour éviter une duplication de code, il faut ajouter chaque nouveau test à la
classe ``RESOURCEXXXTests`` dans ``consumer-newresource/consumer/tests/base.py``.

Chaque test écrit sera alors dupliqué et automagiquement exécuté de la bonne
manière. (Détails dans les commentaires du code).

Quand un test est exécuté en mode "unit", seule la fonction correspondant à la
tâche est exécutée. En mode "functional", la tâche est lancée via celery etc.

.. code-block:: shell

   # Pour lancer des tests unitaires
   $ cd consumer-xxx/consumer/tests/
   $ pytest -m unit


   # Pour lancer des tests fonctionnels dans les conteneurs
   $ docker exec worker-resourcexxx pytest -m functional

Si le flag ``-m`` n'est pas spécifié, tous les tests seront exécutés dans les
deux modes.

Initialisation du projet Git
============================

L'initialisation d'un projet git permet de :

* Créer un projet sur GitHub (dans une organisation ou pour un utilisateur)
* Initialiser la branche master avec un premier commit "Init"
* Push les sources sur le projet
* Utilisation :

    .. code-block:: shell

       usage: flaskit_init_git.py [-h] [--username USERNAME] [--password PASSWORD]
                           --auth-method {https,ssh} [--email EMAIL] --name
                           NAME --type {user,org} [--org ORG] --folder FOLDER
                           [--private]

        Create Github projects

        optional arguments:
          -h, --help            show this help message and exit
          --username USERNAME   Github username. Use also GITHUB_USERNAME environment
                                var
          --password PASSWORD   Github password. Use also GITHUB_PASSWORD environment
                                var
          --auth-method {https,ssh}
                                Github repository authentication method
          --email EMAIL         Email. Use also GITHUB_EMAIL environment var
          --name NAME           Name of the repository
          --type {user,org}     Create repository for user or organisation
          --org ORG             Organisation name. Required if type is "org"
          --folder FOLDER       Project folder location
          --private             Create private repository

* `--auth-method` permet d'initialiser le dépot en local pour pousser soit via SSH, soit en HTTPS.
* Ex:

    .. code-block:: shell

        flaskit_init_git.py --auth-method ssh --name test3 --folder test3/ --type user

Initialisation du projet Openshift
==================================

L'initialisation d'un projet Openshift permet de :

* Créer un projet dans Openshift (`oc new-project`)
* Instancier le Jenkins pour ce projet d'API

**Pré-requis**

* Se logger sur l'Openshift avec votre client `oc` :

    .. code-block:: shell

        oc login -u 2000XXXX https://URL_OPENSHIFT_DEV

* Se placer dans le dossier Git de votre projet précédemment créé. L'initialisation ira par défaut chercher un fichier au chemin relatif `./install/manifests/bootstrap-oc-project.yaml`.

**Utilisation**

* Utilisation :

    .. code-block:: shell

        usage: flaskit_init_oc_project.py [-h] --name NAME
                                  [--bootstrap-manifest BOOTSTRAP_MANIFEST]

        Create Github projects

        Optional arguments:
          -h, --help            show this help message and exit
          --name NAME           Name of the repository
          --bootstrap-manifest BOOTSTRAP_MANIFEST
                                Bootstrap manifest from your API project

* Ex :

    .. code-block:: shell

        ~/myapitest $ flaskit_init_oc_project.py --name myapitest
        developer

        ### Create openshift project...

        Now using project "myapitest" on server "https://192.168.42.14:8443".

        You can add applications to this project with the 'new-app' command. For example, try:

            oc new-app centos/ruby-22-centos7~https://github.com/openshift/ruby-ex.git

        to build a new example application in Ruby.

        ### Boostrap Flaskit project on Openshift...

        imagestream "jenkins-2-centos7" created
        imagestream "redis" created
        buildconfig "redis" created
        route "jenkins" created
        service "jenkins-jnlp" created
        service "jenkins" created
        persistentvolumeclaim "jenkins" created
        deploymentconfig "jenkins" created
        serviceaccount "jenkins" created
        rolebinding "jenkins_edit" created


Initialisation d'une branche dans le projet
===========================================

**Pré-requis**

* Étape initialisation du projet dans Openshift

**Utilisation**

* Usage:

  .. code-block:: shell

      usage: flaskit_init_branch.py [-h] [--git-user GIT_USER]
                                    [--git-password GIT_PASSWORD]
                                    [--git-url GIT_URL] [--git-branch GIT_BRANCH]
                                    [--flaskit-git-user FLASKIT_GIT_USER]
                                    [--flaskit-git-password FLASKIT_GIT_PASSWORD]
                                    [--flaskit-git-url FLASKIT_GIT_URL]
                                    [--flaskit-git-branch FLASKIT_GIT_BRANCH]
                                    [--manifest MANIFEST]

      Bootstrap a new branch on openshift

      optional arguments:
        -h, --help            show this help message and exit
        --git-user GIT_USER   GitHub username
        --git-password GIT_PASSWORD
                              GitHub password or token
        --git-url GIT_URL     GitHub project URL
        --git-branch GIT_BRANCH
                              Git branch to bootstrap
        --flaskit-git-user FLASKIT_GIT_USER
                              FlaskIT Git project user
        --flaskit-git-password FLASKIT_GIT_PASSWORD
                              FlaskIT Git project password or token
        --flaskit-git-url FLASKIT_GIT_URL
                              FlaskIT Git project URL
        --flaskit-git-branch FLASKIT_GIT_BRANCH
                              FlaskIT Git project branch
        --manifest MANIFEST   Path of deploy-branch manifest


* Ex:

  .. code-block:: shell

      flaskit_init_branch.py --git-user 2000XXXX \
        --git-url https://github.com/adeo/myapitest \
        --git-password PASSWORD_OR_ENVVAR \
        --git-branch master \
        --flaskit-git-user fhardy \
        --flaskit-git-password $(pass ol/adeo/ol-gitlab-token) \
        --flaskit-git-url https://gitlab.objectif-libre.com/clients/Adeo/flaskit-poc.git \
        --flaskit-git-branch master
